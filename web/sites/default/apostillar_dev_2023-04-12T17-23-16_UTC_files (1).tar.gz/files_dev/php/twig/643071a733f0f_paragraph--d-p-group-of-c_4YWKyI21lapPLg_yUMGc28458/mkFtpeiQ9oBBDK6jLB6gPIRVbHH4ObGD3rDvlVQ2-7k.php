<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* profiles/contrib/droopler/modules/custom/d_p_counters/templates/paragraph--d-p-group-of-counters.html.twig */
class __TwigTemplate_02f9bfdf01ae040e856795644335009cbe1c4b515bbcf353df610f3655a8288b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'paragraph' => [$this, 'block_paragraph'],
            'background' => [$this, 'block_background'],
            'content' => [$this, 'block_content'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 41
        $context["classes"] = [0 => "paragraph", 1 => "clearfix", 2 => ("paragraph--type--" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source,         // line 44
($context["paragraph"] ?? null), "bundle", [], "any", false, false, true, 44), 44, $this->source))), 3 => ((        // line 45
($context["view_mode"] ?? null)) ? (("paragraph--view-mode--" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(($context["view_mode"] ?? null), 45, $this->source)))) : (""))];
        // line 47
        $context["paragraph_classes"] = [0 => "d-p-counters"];
        // line 50
        echo "
";
        // line 51
        $this->displayBlock('paragraph', $context, $blocks);
    }

    public function block_paragraph($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 52
        echo "<section ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["wrapper_attributes"] ?? null), 52, $this->source), "html", null, true);
        echo ">
  <div";
        // line 53
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [0 => ($context["classes"] ?? null)], "method", false, false, true, 53), 53, $this->source), "html", null, true);
        echo ">
    <div ";
        // line 54
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["paragraph_attributes"] ?? null), "addClass", [0 => ($context["paragraph_classes"] ?? null)], "method", false, false, true, 54), 54, $this->source), "html", null, true);
        echo ">
      ";
        // line 55
        $this->displayBlock('background', $context, $blocks);
        // line 60
        echo "      <div class=\"content-wrapper\">
        <div class=\"content container\">
          ";
        // line 62
        $this->displayBlock('content', $context, $blocks);
        // line 65
        echo "        </div>
        ";
        // line 66
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["content"] ?? null), "group_d_counters_content", [], "any", false, false, true, 66), "field_d_cta_link", [], "any", false, false, true, 66), 0, [], "any", false, false, true, 66)) {
            // line 67
            echo "          <div class=\"text-center mt-4\">
            ";
            // line 68
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["content"] ?? null), "group_d_counters_content", [], "any", false, false, true, 68), "field_d_cta_link", [], "any", false, false, true, 68), 68, $this->source), "html", null, true);
            echo "
          </div>
        ";
        }
        // line 71
        echo "      </div>
    </div>
  </div>
</section>
";
    }

    // line 55
    public function block_background($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 56
        echo "        ";
        $this->loadTemplate("@d_media/d-background-media.html.twig", "profiles/contrib/droopler/modules/custom/d_p_counters/templates/paragraph--d-p-group-of-counters.html.twig", 56)->display(twig_to_array(["content" => twig_get_attribute($this->env, $this->source,         // line 57
($context["content"] ?? null), "group_d_counters_background", [], "any", false, false, true, 57)]));
        // line 59
        echo "      ";
    }

    // line 62
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 63
        echo "            ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["content"] ?? null), "group_d_counters_content", [], "any", false, false, true, 63), 63, $this->source), "field_d_cta_link"), "html", null, true);
        echo "
          ";
    }

    public function getTemplateName()
    {
        return "profiles/contrib/droopler/modules/custom/d_p_counters/templates/paragraph--d-p-group-of-counters.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 63,  113 => 62,  109 => 59,  107 => 57,  105 => 56,  101 => 55,  93 => 71,  87 => 68,  84 => 67,  82 => 66,  79 => 65,  77 => 62,  73 => 60,  71 => 55,  67 => 54,  63 => 53,  58 => 52,  51 => 51,  48 => 50,  46 => 47,  44 => 45,  43 => 44,  42 => 41,);
    }

    public function getSourceContext()
    {
        return new Source("", "profiles/contrib/droopler/modules/custom/d_p_counters/templates/paragraph--d-p-group-of-counters.html.twig", "/code/web/profiles/contrib/droopler/modules/custom/d_p_counters/templates/paragraph--d-p-group-of-counters.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 41, "block" => 51, "if" => 66, "include" => 56);
        static $filters = array("clean_class" => 44, "escape" => 52, "without" => 63);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'if', 'include'],
                ['clean_class', 'escape', 'without'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
