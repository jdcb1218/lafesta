<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* profiles/contrib/droopler/modules/custom/d_p_side_embed/templates/paragraph--d-p-side-embed.html.twig */
class __TwigTemplate_55ffc3b40227a82c98692fcbc5693df93398c7ad17b11614d466006680c84c58 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'paragraph' => [$this, 'block_paragraph'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 41
        $context["classes"] = [0 => "paragraph", 1 => "container-fluid", 2 => "d-p-side-embed", 3 => "content-moved-inside", 4 => ("paragraph--type--" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source,         // line 46
($context["paragraph"] ?? null), "bundle", [], "any", false, false, true, 46), 46, $this->source))), 5 => ((        // line 47
($context["view_mode"] ?? null)) ? (("paragraph--view-mode--" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(($context["view_mode"] ?? null), 47, $this->source)))) : (""))];
        // line 49
        $context["d_p_side_embed_wrapper_classes"] = [0 => "clearfix", 1 => "d-p-side-embed-wrapper", 2 => "row", 3 => ("embed-side-" . $this->sandbox->ensureToStringAllowed(        // line 53
($context["embed_side"] ?? null), 53, $this->source))];
        // line 55
        echo "
";
        // line 56
        $context["embed_side_classes"] = [0 => "d-p-side-embed-embed", 1 => (((        // line 58
($context["embed_side"] ?? null) == "full")) ? ("col-12") : ("col-md-6"))];
        // line 60
        $context["content_side_classes"] = [0 => "d-p-side-embed-content", 1 => "content-inside-wrapper", 2 => (((        // line 63
($context["embed_side"] ?? null) == "full")) ? ("col-md-6 col-12 d-flex justify-content-end") : ("col-md-6"))];
        // line 65
        $context["content_fields_classes"] = [0 => "d-p-side-embed-content-fields", 1 => (((        // line 67
($context["embed_side"] ?? null) == "full")) ? ("d-flex flex-column container-half") : (""))];
        // line 69
        echo "
";
        // line 70
        $this->displayBlock('paragraph', $context, $blocks);
    }

    public function block_paragraph($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 71
        echo "<section ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["wrapper_attributes"] ?? null), 71, $this->source), "html", null, true);
        echo ">
  <div";
        // line 72
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [0 => ($context["classes"] ?? null)], "method", false, false, true, 72), 72, $this->source), "html", null, true);
        echo ">
    <div ";
        // line 73
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["d_p_side_embed_wrapper_attributes"] ?? null), "addClass", [0 => ($context["d_p_side_embed_wrapper_classes"] ?? null)], "method", false, false, true, 73), 73, $this->source), "html", null, true);
        echo ">
      <div ";
        // line 74
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["embed_side_attributes"] ?? null), "addClass", [0 => ($context["embed_side_classes"] ?? null)], "method", false, false, true, 74), 74, $this->source), "html", null, true);
        echo ">
        ";
        // line 75
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->sandbox->ensureToStringAllowed(($context["embed"] ?? null), 75, $this->source));
        echo "
      </div>
      <div ";
        // line 77
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["content_side_attributes"] ?? null), "addClass", [0 => ($context["content_side_classes"] ?? null)], "method", false, false, true, 77), 77, $this->source), "html", null, true);
        echo ">
        <div ";
        // line 78
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["content_fields_attributes"] ?? null), "addClass", [0 => ($context["content_fields_classes"] ?? null)], "method", false, false, true, 78), 78, $this->source), "html", null, true);
        echo ">
          ";
        // line 79
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->withoutFilter($this->sandbox->ensureToStringAllowed(($context["content"] ?? null), 79, $this->source), "field_d_embed", "field_d_cta_link"), "html", null, true);
        echo "
          ";
        // line 80
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["content"] ?? null), "field_d_cta_link", [], "any", false, false, true, 80), 0, [], "any", false, false, true, 80)) {
            // line 81
            echo "            <div class=\"mt-4\">
              ";
            // line 82
            echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["content"] ?? null), "field_d_cta_link", [], "any", false, false, true, 82), 82, $this->source), "html", null, true);
            echo "
            </div>
          ";
        }
        // line 85
        echo "        </div>
      </div>
    </div>
  </div>
</section>
";
    }

    public function getTemplateName()
    {
        return "profiles/contrib/droopler/modules/custom/d_p_side_embed/templates/paragraph--d-p-side-embed.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 85,  108 => 82,  105 => 81,  103 => 80,  99 => 79,  95 => 78,  91 => 77,  86 => 75,  82 => 74,  78 => 73,  74 => 72,  69 => 71,  62 => 70,  59 => 69,  57 => 67,  56 => 65,  54 => 63,  53 => 60,  51 => 58,  50 => 56,  47 => 55,  45 => 53,  44 => 49,  42 => 47,  41 => 46,  40 => 41,);
    }

    public function getSourceContext()
    {
        return new Source("", "profiles/contrib/droopler/modules/custom/d_p_side_embed/templates/paragraph--d-p-side-embed.html.twig", "/code/web/profiles/contrib/droopler/modules/custom/d_p_side_embed/templates/paragraph--d-p-side-embed.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 41, "block" => 70, "if" => 80);
        static $filters = array("clean_class" => 46, "escape" => 71, "raw" => 75, "without" => 79);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block', 'if'],
                ['clean_class', 'escape', 'raw', 'without'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
