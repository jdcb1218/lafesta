<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* profiles/contrib/droopler/modules/custom/d_p_form/templates/paragraph--d-p-form.html.twig */
class __TwigTemplate_c615f39305093ee9104e3072e7e088cb32b76d6e3caefbb0282b2c7bc46d99e8 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'paragraph' => [$this, 'block_paragraph'],
            'background' => [$this, 'block_background'],
            'content' => [$this, 'block_content'],
            'form' => [$this, 'block_form'],
        ];
        $this->sandbox = $this->env->getExtension('\Twig\Extension\SandboxExtension');
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 41
        $context["classes"] = [0 => "paragraph", 1 => ("paragraph--type--" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source,         // line 43
($context["paragraph"] ?? null), "bundle", [], "any", false, false, true, 43), 43, $this->source))), 2 => "with-forced-long-text-margin", 3 => ((        // line 45
($context["view_mode"] ?? null)) ? (("paragraph--view-mode--" . \Drupal\Component\Utility\Html::getClass($this->sandbox->ensureToStringAllowed(($context["view_mode"] ?? null), 45, $this->source)))) : (""))];
        // line 47
        $context["paragraph_classes"] = [0 => "paragraph-d-form"];
        // line 50
        echo "
";
        // line 51
        $context["d_p_form_placement"] = ((array_key_exists("d_p_form_placement", $context)) ? (_twig_default_filter($this->sandbox->ensureToStringAllowed(($context["d_p_form_placement"] ?? null), 51, $this->source), "bottom")) : ("bottom"));
        // line 52
        echo "
";
        // line 53
        if ((($context["d_p_form_placement"] ?? null) == "bottom")) {
            // line 54
            echo "  ";
            $context["row_classes"] = "";
            // line 55
            echo "  ";
            $context["content_classes"] = "col-md-8";
            // line 56
            echo "  ";
            $context["form_classes"] = "col-md-8";
        }
        // line 58
        if ((($context["d_p_form_placement"] ?? null) == "right")) {
            // line 59
            echo "  ";
            $context["row_classes"] = "";
            // line 60
            echo "  ";
            $context["content_classes"] = "col-md-5 col-12";
            // line 61
            echo "  ";
            $context["form_classes"] = "col-md-7 col-12";
        }
        // line 63
        if ((($context["d_p_form_placement"] ?? null) == "left")) {
            // line 64
            echo "  ";
            $context["row_classes"] = "";
            // line 65
            echo "  ";
            $context["content_classes"] = "col-md-5 col-12 order-1 order-md-2";
            // line 66
            echo "  ";
            $context["form_classes"] = "col-md-7 col-12 order-md-1 order-2";
        }
        // line 68
        echo "
";
        // line 69
        $this->displayBlock('paragraph', $context, $blocks);
    }

    public function block_paragraph($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 70
        echo "  <section ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["wrapper_attributes"] ?? null), 70, $this->source), "html", null, true);
        echo ">
    <div";
        // line 71
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["attributes"] ?? null), "addClass", [0 => ($context["classes"] ?? null)], "method", false, false, true, 71), 71, $this->source), "html", null, true);
        echo ">
      <div ";
        // line 72
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["paragraph_attributes"] ?? null), "addClass", [0 => ($context["paragraph_classes"] ?? null)], "method", false, false, true, 72), 72, $this->source), "html", null, true);
        echo ">
        ";
        // line 73
        $this->displayBlock('background', $context, $blocks);
        // line 78
        echo "        <div class=\"content-wrapper\">
          <div class=\"container\">
            <div class=\"row justify-content-center ";
        // line 80
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["d_p_form_placement"] ?? null), 80, $this->source), "html", null, true);
        echo " ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["row_classes"] ?? null), 80, $this->source), "html", null, true);
        echo "\">
              <div class=\"content ";
        // line 81
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["content_classes"] ?? null), 81, $this->source), "html", null, true);
        echo "\">
                ";
        // line 82
        $this->displayBlock('content', $context, $blocks);
        // line 85
        echo "              </div>
              <div class=\"form ";
        // line 86
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(($context["form_classes"] ?? null), 86, $this->source), "html", null, true);
        echo "\">
                ";
        // line 87
        $this->displayBlock('form', $context, $blocks);
        // line 90
        echo "              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
";
    }

    // line 73
    public function block_background($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 74
        echo "          ";
        $this->loadTemplate("@d_media/d-background-media.html.twig", "profiles/contrib/droopler/modules/custom/d_p_form/templates/paragraph--d-p-form.html.twig", 74)->display(twig_to_array(["content" => twig_get_attribute($this->env, $this->source,         // line 75
($context["content"] ?? null), "group_d_form_background", [], "any", false, false, true, 75)]));
        // line 77
        echo "        ";
    }

    // line 82
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 83
        echo "                  ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["content"] ?? null), "group_d_form_content", [], "any", false, false, true, 83), 83, $this->source), "html", null, true);
        echo "
                ";
    }

    // line 87
    public function block_form($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 88
        echo "                  ";
        echo $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->sandbox->ensureToStringAllowed(twig_get_attribute($this->env, $this->source, ($context["content"] ?? null), "group_d_form_fields", [], "any", false, false, true, 88), 88, $this->source), "html", null, true);
        echo "
                ";
    }

    public function getTemplateName()
    {
        return "profiles/contrib/droopler/modules/custom/d_p_form/templates/paragraph--d-p-form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  181 => 88,  177 => 87,  170 => 83,  166 => 82,  162 => 77,  160 => 75,  158 => 74,  154 => 73,  143 => 90,  141 => 87,  137 => 86,  134 => 85,  132 => 82,  128 => 81,  122 => 80,  118 => 78,  116 => 73,  112 => 72,  108 => 71,  103 => 70,  96 => 69,  93 => 68,  89 => 66,  86 => 65,  83 => 64,  81 => 63,  77 => 61,  74 => 60,  71 => 59,  69 => 58,  65 => 56,  62 => 55,  59 => 54,  57 => 53,  54 => 52,  52 => 51,  49 => 50,  47 => 47,  45 => 45,  44 => 43,  43 => 41,);
    }

    public function getSourceContext()
    {
        return new Source("", "profiles/contrib/droopler/modules/custom/d_p_form/templates/paragraph--d-p-form.html.twig", "/code/web/profiles/contrib/droopler/modules/custom/d_p_form/templates/paragraph--d-p-form.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = array("set" => 41, "if" => 53, "block" => 69, "include" => 74);
        static $filters = array("clean_class" => 43, "default" => 51, "escape" => 70);
        static $functions = array();

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block', 'include'],
                ['clean_class', 'default', 'escape'],
                []
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
